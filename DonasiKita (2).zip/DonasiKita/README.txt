DONASIKITA - PROJECT PRAKTIKUM PEMROGRAMAN WEB

FITUR
- Registrasi, login, logout dengan session dan profil pengguna.
- Sistem kampanye: melihat kampanye dan menambahkan kampanye baru.
- Rekomendasi kampanye berdasarkan kategori dan kata kunci kebutuhan.
- Sistem donasi: mencatat donasi uang atau barang ke kampanye pilihan.
- Riwayat donasi personal berdasarkan akun yang sedang login.
- Laporan target, jumlah dana terkumpul, persentase pencapaian, jumlah transaksi, dan status penyaluran.
- Data disimpan dalam file JSON, tanpa database: data/users.json, data/campaigns.json, data/donations.json.
- Password akun disimpan dalam bentuk hash.
- Layout responsif untuk desktop dan ponsel.

CARA MENJALANKAN DI XAMPP
1. Ekstrak folder DonasiKita ke C:\xampp\htdocs\
2. Buka XAMPP Control Panel, lalu Start Apache.
3. Pastikan folder data dapat ditulisi oleh PHP.
4. Buka http://localhost/DonasiKita/
5. Daftar akun lalu login.

CATATAN
- Fitur donasi hanya mencatat transaksi untuk keperluan proyek; belum terhubung dengan payment gateway.
- Kampanye awal merupakan data contoh dan dapat ditambah dari halaman Kampanye Donasi.
- Status penyaluran bisa diperbarui pada field "distribution" di data/campaigns.json.
- Untuk penggunaan produksi, gunakan database, proteksi CSRF, validasi lebih lanjut, dan konfigurasi server yang sesuai.
