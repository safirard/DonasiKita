<?php
require __DIR__ . '/includes/auth.php'; require __DIR__ . '/includes/donation_helpers.php';
$pageTitle='Kampanye Donasi'; $activePage='campaigns'; $file=dk_campaigns_file(); $campaigns=dk_read_json($file); $success=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $title=trim($_POST['title']??''); $category=trim($_POST['category']??''); $desc=trim($_POST['desc']??''); $target=(int)($_POST['target']??0); $type=$_POST['type']??'Uang';
 if ($title==='' || $desc==='' || $target<1) $error='Isi semua data kampanye dengan benar.';
 else { $campaigns[]=['id'=>'C'.strtoupper(bin2hex(random_bytes(3))),'category'=>$category,'title'=>$title,'desc'=>$desc,'target'=>$target,'collected'=>0,'type'=>$type,'status'=>'Aktif','distribution'=>'Belum ada penyaluran']; if(dk_write_json($file,$campaigns)) $success='Kampanye berhasil ditambahkan.'; else $error='Kampanye gagal disimpan.'; }
}
require __DIR__ . '/includes/header.php';
?>
<div class="section-heading"><div><div class="eyebrow">BERSAMA BERBAGI</div><h1>Kampanye Donasi</h1><p class="muted">Pilih kampanye yang ingin kamu dukung atau tambahkan kampanye baru.</p></div></div>
<?php if($success):?><div class="alert success"><?=e($success)?></div><?php endif;?><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?>
<div class="campaign-grid">
<?php foreach($campaigns as $c): if(($c['status']??'Aktif')!=='Aktif') continue; $pct=($c['target']??0)>0?min(100,round(($c['collected']??0)/$c['target']*100)):0; ?>
<article class="campaign-card"><div class="campaign-visual mint"><span class="campaign-symbol">♡</span><span class="campaign-tag"><?=e($c['category'])?></span><span class="visual-caption">Kebaikan dimulai dari kita</span></div><div class="campaign-body"><h3><?=e($c['title'])?></h3><p><?=e($c['desc'])?></p><div class="progress-label"><span>Terkumpul</span><strong><?=$pct?>%</strong></div><div class="progress-track"><div class="progress-fill" style="width:<?=$pct?>%"></div></div><div class="funding"><div><strong><?=dk_rupiah($c['collected']??0)?></strong><span>dari <?=dk_rupiah($c['target'])?></span></div></div><a class="btn outline full" href="donate.php?campaign=<?=urlencode($c['id'])?>">Donasi Sekarang →</a></div></article>
<?php endforeach;?></div>
<section class="profile-card" style="margin-top:28px;padding:24px"><div class="card-heading"><div><h2>Tambah Kampanye</h2><p class="muted">Data disimpan pada file data/campaigns.json.</p></div></div><form method="post" class="profile-form"><div class="form-row"><div><label>Nama kampanye</label><input name="title" required></div><div><label>Kategori</label><select name="category"><option>Pendidikan</option><option>Kesehatan</option><option>Bencana</option><option>Sosial</option></select></div></div><div><label>Deskripsi</label><textarea name="desc" rows="3" required></textarea></div><div class="form-row"><div><label>Target donasi (Rp)</label><input type="number" name="target" min="1" required></div><div><label>Jenis bantuan</label><select name="type"><option>Uang</option><option>Barang</option><option>Uang atau Barang</option></select></div></div><button class="btn primary" type="submit">Tambah Kampanye →</button></form></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
