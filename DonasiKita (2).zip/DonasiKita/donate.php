<?php
require __DIR__ . '/includes/auth.php'; require __DIR__ . '/includes/donation_helpers.php';
$pageTitle='Donasi'; $activePage='donate'; $cf=dk_campaigns_file(); $df=dk_donations_file(); $campaigns=dk_read_json($cf); $donations=dk_read_json($df); $success=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $cid=$_POST['campaign_id']??''; $amount=(int)($_POST['amount']??0); $kind=$_POST['kind']??'Uang'; $note=trim($_POST['note']??''); $chosen=null;
 foreach($campaigns as $i=>$c) if($c['id']===$cid){$chosen=$i;break;}
 if($chosen===null) $error='Silakan pilih kampanye yang tersedia.';
 elseif($kind==='Uang' && $amount<1000) $error='Nominal donasi uang minimal Rp1.000.';
 elseif($kind==='Barang' && $note==='') $error='Tuliskan barang yang ingin disumbangkan pada catatan.';
 else { $value=$kind==='Uang'?$amount:0; $donations[]=['id'=>'D'.strtoupper(bin2hex(random_bytes(4))),'user_id'=>$currentUser['id'],'user_name'=>$currentUser['name'],'campaign_id'=>$cid,'campaign_title'=>$campaigns[$chosen]['title'],'category'=>$campaigns[$chosen]['category'],'kind'=>$kind,'amount'=>$value,'note'=>$note,'date'=>date('Y-m-d H:i:s'),'status'=>'Tercatat']; $campaigns[$chosen]['collected']=(int)($campaigns[$chosen]['collected']??0)+$value; if(dk_write_json($df,$donations)&&dk_write_json($cf,$campaigns)) $success='Terima kasih! Donasimu berhasil dicatat.'; else $error='Donasi belum dapat disimpan. Periksa izin folder data.'; }
}
$selected=$_GET['campaign']??''; require __DIR__ . '/includes/header.php';
?>
<div class="profile-intro"><div><div class="eyebrow">SALURKAN KEBAIKAN</div><h1>Form Donasi</h1><p class="muted">Pilih kampanye dan tentukan bantuan yang ingin kamu berikan.</p></div></div>
<?php if($success):?><div class="alert success"><?=e($success)?> <a href="history.php">Lihat riwayat</a></div><?php endif;?><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?>
<section class="profile-card" style="max-width:760px;padding:26px"><form method="post" class="profile-form"><div><label for="campaign_id">Pilih kampanye</label><select name="campaign_id" id="campaign_id" required><option value="">-- Pilih kampanye --</option><?php foreach($campaigns as $c):if(($c['status']??'Aktif')==='Aktif'):?><option value="<?=e($c['id'])?>" <?=$selected===$c['id']?'selected':''?>><?=e($c['title'])?> (<?=e($c['category'])?>)</option><?php endif;endforeach;?></select></div><div class="form-row"><div><label for="kind">Jenis bantuan</label><select name="kind" id="kind"><option>Uang</option><option>Barang</option></select></div><div><label for="amount">Nominal uang (Rp)</label><input type="number" name="amount" id="amount" min="1000" step="1000" value="10000"></div></div><div><label for="note">Catatan / jenis barang</label><textarea name="note" id="note" rows="3" placeholder="Contoh: buku tulis, beras, atau pesan untuk penerima bantuan"></textarea></div><button class="btn primary" type="submit">Kirim Donasi ♥</button></form><p class="muted" style="margin-top:16px">Catatan: ini merupakan pencatatan donasi untuk keperluan proyek, belum terhubung ke pembayaran online.</p></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
