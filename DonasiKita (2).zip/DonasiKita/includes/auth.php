<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
$usersFile = __DIR__ . '/../data/users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];
if (!is_array($users)) $users = [];
$currentUser = null;
foreach ($users as $user) {
    if ($user['id'] === $_SESSION['user']) { $currentUser = $user; break; }
}
if (!$currentUser) {
    session_destroy();
    header('Location: login.php');
    exit;
}
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function initials($name) {
    $parts = preg_split('/\s+/', trim($name));
    $out = '';
    foreach (array_slice($parts, 0, 2) as $part) $out .= strtoupper(substr($part, 0, 1));
    return $out ?: 'U';
}
