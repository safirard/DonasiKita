<?php
function dk_read_json($path, $default = []) {
    if (!file_exists($path)) return $default;
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : $default;
}
function dk_write_json($path, $data) {
    return file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false;
}
function dk_rupiah($n) { return 'Rp' . number_format((float)$n, 0, ',', '.'); }
function dk_campaigns_file() { return __DIR__ . '/../data/campaigns.json'; }
function dk_donations_file() { return __DIR__ . '/../data/donations.json'; }
