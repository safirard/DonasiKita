</div>
<footer class="page-footer">© <?= date('Y') ?> DonasiKita · Tumbuhkan kepedulian, sebarkan kebaikan.</footer>
</main></div><script src="assets/script.js"></script></body></html>
