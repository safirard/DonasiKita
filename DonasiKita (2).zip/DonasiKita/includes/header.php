<?php $activePage = $activePage ?? ''; ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title><?= e($pageTitle ?? 'Dashboard') ?> | DonasiKita</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="app-page">
<div class="app-layout">
<aside class="sidebar" id="sidebar">
  <a class="brand" href="dashboard.php"><span class="brand-mark">♥</span> DonasiKita</a>
  <div class="nav-label">MENU UTAMA</div>
  <nav class="side-nav">
    <a class="<?= $activePage==='dashboard'?'active':'' ?>" href="dashboard.php"><span>▦</span> Dashboard</a>
    <a class="<?= $activePage==='campaigns'?'active':'' ?>" href="campaigns.php"><span>♡</span> Kampanye Donasi</a>
    <a class="<?= $activePage==='recommendations'?'active':'' ?>" href="recommendations.php"><span>✦</span> Rekomendasi</a>
    <a class="<?= $activePage==='donate'?'active':'' ?>" href="donate.php"><span>＋</span> Donasi</a>
    <a class="<?= $activePage==='history'?'active':'' ?>" href="history.php"><span>◷</span> Riwayat Donasi</a>
    <a class="<?= $activePage==='reports'?'active':'' ?>" href="reports.php"><span>▤</span> Laporan Donasi</a>
    <a class="<?= $activePage==='profile'?'active':'' ?>" href="profile.php"><span>◎</span> Profil Saya</a>
  </nav>
  <div class="sidebar-bottom">
    <div class="help-card"><span class="help-icon">♡</span><strong>Berbagi itu berarti</strong><p>Setiap bantuan membawa harapan baru.</p></div>
    <a class="side-logout" href="logout.php"><span>↪</span> Keluar</a>
  </div>
</aside>
<main class="main-content">
<header class="topbar">
  <button class="menu-toggle" id="menuToggle" aria-label="Buka menu">☰</button>
  <div class="breadcrumb">DonasiKita <span>/</span> <?= e($pageTitle ?? '') ?></div>
  <a class="top-user" href="profile.php"><span class="avatar small"><?= e(initials($currentUser['name'])) ?></span><span class="top-user-name"><?= e($currentUser['name']) ?></span><span class="chevron">⌄</span></a>
</header>
<div class="page-content">
