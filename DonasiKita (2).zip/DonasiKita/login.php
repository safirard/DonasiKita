<?php
session_start();
if (isset($_SESSION['user'])) { header('Location: dashboard.php'); exit; }
$usersFile = __DIR__ . '/data/users.json';
$error = '';
$email = '';
if (!empty($_SESSION['flash'])) { $flash = $_SESSION['flash']; unset($_SESSION['flash']); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];
    if (!is_array($users)) $users = [];
    foreach ($users as $user) {
        if (strtolower($user['email']) === $email && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = $user['id'];
            header('Location: dashboard.php');
            exit;
        }
    }
    $error = 'Email atau password tidak sesuai.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Login | DonasiKita</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-page">
<div class="auth-shell">
  <a class="brand auth-brand" href="login.php"><span class="brand-mark">♥</span> DonasiKita</a>
  <div class="auth-card">
    <div class="eyebrow">SELAMAT DATANG KEMBALI</div>
    <h1>Login akunmu</h1>
    <p class="muted">Lanjutkan langkah kecilmu untuk membawa perubahan.</p>
    <?php if (!empty($flash)): ?><div class="alert success"><?= htmlspecialchars($flash) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="post">
      <label for="email">Email</label>
      <input id="email" name="email" type="email" placeholder="nama@email.com" value="<?= htmlspecialchars($email) ?>" required>
      <label for="password">Password</label>
      <input id="password" name="password" type="password" placeholder="Masukkan password" required>
      <button class="btn primary full" type="submit">Login <span>→</span></button>
    </form>
    <p class="auth-switch">Belum punya akun? <a href="register.php">Daftar sekarang</a></p>
  </div>
  <p class="auth-footer">Satu kebaikan kecil, berarti besar bagi sesama.</p>
</div>
</body></html>
