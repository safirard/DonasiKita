<?php
require __DIR__ . '/includes/auth.php';
$pageTitle = 'Profil Saya'; $activePage = 'profile';
$success = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    if ($name === '') $error = 'Nama lengkap wajib diisi.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Format email belum benar.';
    else {
        foreach ($users as $u) {
            if ($u['id'] !== $currentUser['id'] && strtolower($u['email']) === $email) $error = 'Email tersebut sudah digunakan akun lain.';
        }
        if (!$error) {
            foreach ($users as &$u) {
                if ($u['id'] === $currentUser['id']) {
                    $u['name'] = $name; $u['email'] = $email; $u['phone'] = $phone; $u['bio'] = $bio;
                    $currentUser = $u; break;
                }
            }
            unset($u);
            file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
            $success = 'Profil berhasil diperbarui.';
        }
    }
}
require __DIR__ . '/includes/header.php';
?>
<div class="profile-intro"><div><div class="eyebrow">AKUN SAYA</div><h1>Profil Saya</h1><p class="muted">Kelola informasi akunmu di DonasiKita.</p></div></div>
<?php if ($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<div class="profile-layout">
  <section class="profile-card profile-summary">
    <div class="profile-cover"></div>
    <div class="profile-avatar avatar"><?= e(initials($currentUser['name'])) ?></div>
    <h2><?= e($currentUser['name']) ?></h2><p class="muted"><?= e($currentUser['email']) ?></p>
    <span class="member-pill"><span>●</span> Anggota DonasiKita</span>
    <div class="summary-divider"></div>
    <div class="summary-detail"><span>♧</span><div><small>Status akun</small><strong>Aktif</strong></div></div>
    <div class="summary-detail"><span>♡</span><div><small>Bergabung sejak</small><strong><?= date('d M Y', strtotime($currentUser['created_at'] ?? 'now')) ?></strong></div></div>
  </section>
  <section class="profile-card profile-form-card">
    <div class="card-heading"><div><h2>Informasi pribadi</h2><p class="muted">Pastikan informasi akunmu selalu terbaru.</p></div><span class="edit-symbol">✎</span></div>
    <form method="post" class="profile-form">
      <div class="form-row"><div><label for="name">Nama lengkap</label><input id="name" name="name" value="<?= e($currentUser['name']) ?>" required></div><div><label for="email">Alamat email</label><input id="email" name="email" type="email" value="<?= e($currentUser['email']) ?>" required></div></div>
      <div><label for="phone">Nomor telepon</label><input id="phone" name="phone" type="tel" value="<?= e($currentUser['phone'] ?? '') ?>" placeholder="Contoh: 081234567890"></div>
      <div><label for="bio">Tentang saya</label><textarea id="bio" name="bio" rows="4" placeholder="Ceritakan sedikit tentang dirimu..."><?= e($currentUser['bio'] ?? '') ?></textarea></div>
      <div class="form-actions"><button class="btn primary" type="submit">Simpan Perubahan <span>→</span></button></div>
    </form>
  </section>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
