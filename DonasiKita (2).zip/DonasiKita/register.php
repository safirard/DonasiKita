<?php
session_start();
$usersFile = __DIR__ . '/data/users.json';
$errors = [];
$name = $email = '';
function loadUsers($file) {
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    if ($name === '') $errors[] = 'Nama lengkap wajib diisi.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email belum benar.';
    if (strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
    if ($password !== $confirm) $errors[] = 'Konfirmasi password tidak sama.';
    $users = loadUsers($usersFile);
    foreach ($users as $user) {
        if (strtolower($user['email']) === $email) {
            $errors[] = 'Email sudah terdaftar. Silakan login.';
            break;
        }
    }
    if (!$errors) {
        $users[] = [
            'id' => uniqid('user_', true),
            'name' => $name,
            'email' => $email,
            'phone' => '',
            'bio' => '',
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s')
        ];
        if (file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false) {
            $_SESSION['flash'] = 'Akun berhasil dibuat. Silakan login.';
            header('Location: login.php');
            exit;
        }
        $errors[] = 'Akun gagal disimpan. Pastikan folder data dapat ditulisi.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Daftar Akun | DonasiKita</title><link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-page">
<div class="auth-shell">
  <a class="brand auth-brand" href="login.php"><span class="brand-mark">♥</span> DonasiKita</a>
  <div class="auth-card">
    <div class="eyebrow">MULAI BERBAGI KEBAIKAN</div>
    <h1>Buat akun baru</h1>
    <p class="muted">Bergabunglah untuk menemukan dan mendukung kampanye sosial di kampus.</p>
    <?php if ($errors): ?><div class="alert error"><?php foreach ($errors as $e) echo '<div>'.htmlspecialchars($e).'</div>'; ?></div><?php endif; ?>
    <form method="post">
      <label for="name">Nama lengkap</label>
      <input id="name" name="name" type="text" placeholder="Masukkan nama lengkap" value="<?= htmlspecialchars($name) ?>" required>
      <label for="email">Email</label>
      <input id="email" name="email" type="email" placeholder="nama@email.com" value="<?= htmlspecialchars($email) ?>" required>
      <label for="password">Password</label>
      <input id="password" name="password" type="password" placeholder="Minimal 6 karakter" minlength="6" required>
      <label for="confirm_password">Konfirmasi password</label>
      <input id="confirm_password" name="confirm_password" type="password" placeholder="Ulangi password" required>
      <button class="btn primary full" type="submit">Buat Akun <span>→</span></button>
    </form>
    <p class="auth-switch">Sudah punya akun? <a href="login.php">Login di sini</a></p>
  </div>
  <p class="auth-footer">Satu kebaikan kecil, berarti besar bagi sesama.</p>
</div>
</body></html>
